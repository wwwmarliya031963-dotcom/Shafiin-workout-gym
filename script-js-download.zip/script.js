const $ = (id) => document.getElementById(id);

function calculateBMI(){
  const h = parseFloat($("height").value)/100, w = parseFloat($("weight").value);
  if(!h || !w) return $("bmiResult").textContent="Please enter height and weight.";
  const bmi = w/(h*h);
  let cat = bmi < 18.5 ? "Underweight" : bmi < 25 ? "Healthy range" : bmi < 30 ? "Overweight" : "Obesity range";
  $("bmiResult").innerHTML = `BMI: <strong>${bmi.toFixed(1)}</strong> — ${cat}`;
}
function calculateCalories(){
  const age=+$("age").value, h=+$("calHeight").value, w=+$("calWeight").value, sex=$("sex").value, act=+$("activity").value;
  if(!age||!h||!w) return $("calorieResult").textContent="Please enter all details.";
  const bmr = sex==="male" ? 10*w+6.25*h-5*age+5 : 10*w+6.25*h-5*age-161;
  const tdee = Math.round(bmr*act);
  $("calorieResult").innerHTML=`Estimated maintenance: <strong>${tdee} kcal/day</strong><br><small>Individual needs vary.</small>`;
}
function calculate1RM(){
  const w=+$("liftWeight").value, r=+$("liftReps").value;
  if(!w||!r) return $("rmResult").textContent="Please enter weight and reps.";
  const rm=w*(1+r/30);
  $("rmResult").innerHTML=`Estimated 1RM: <strong>${rm.toFixed(1)} kg</strong>`;
}
function calculateWater(){
  const w=+$("waterWeight").value;
  if(!w) return $("waterResult").textContent="Please enter your weight.";
  const liters=w*0.033;
  $("waterResult").innerHTML=`Starting target: <strong>${liters.toFixed(1)} L/day</strong><br><small>Increase appropriately for heat/exercise; individual needs vary.</small>`;
}

document.querySelectorAll(".filter").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
    btn.classList.add("active");
    const f=btn.dataset.filter;
    document.querySelectorAll(".exercise-card").forEach(card=>{
      card.style.display=(f==="all"||card.dataset.category===f)?"block":"none";
    });
  });
});

const tasks=[...document.querySelectorAll(".check input")];
function updateProgress(){
  const done=tasks.filter(t=>t.checked).length, pct=Math.round(done/tasks.length*100);
  $("progressBar").style.width=pct+"%";
  $("progressText").textContent=`${pct}% complete`;
  tasks.forEach(t=>localStorage.setItem("shafiin_"+t.dataset.task,t.checked));
}
tasks.forEach(t=>{
  t.checked=localStorage.getItem("shafiin_"+t.dataset.task)==="true";
  t.addEventListener("change",updateProgress);
});
function resetTasks(){
  tasks.forEach(t=>{t.checked=false;localStorage.removeItem("shafiin_"+t.dataset.task)});
  updateProgress();
}
updateProgress();
$("year").textContent=new Date().getFullYear();
$("todayLabel").textContent=new Date().toLocaleDateString(undefined,{weekday:"long",month:"short",day:"numeric"}).toUpperCase();

$("menuToggle").addEventListener("click",()=>document.querySelector("nav").classList.toggle("open"));
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector("nav").classList.remove("open")));
